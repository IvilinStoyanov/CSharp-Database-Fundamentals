﻿namespace Employees.Data.Config
{
    public class DbConfig
    {
        public const string ConnectionString =
            @"Server=GIGABYTE-PC\SQLEXPRESS;Database=Shop;Integrated Security=True;";
    }
}
