﻿namespace Employees.App.Interfaces
{
    public interface ICommand
    {
        void Execute();
    }
}
