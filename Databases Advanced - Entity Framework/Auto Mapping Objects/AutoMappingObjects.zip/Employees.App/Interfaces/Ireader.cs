﻿namespace Employees.App.Interfaces
{
    public interface IReader
    {
        string ReadLine();
    }
}
