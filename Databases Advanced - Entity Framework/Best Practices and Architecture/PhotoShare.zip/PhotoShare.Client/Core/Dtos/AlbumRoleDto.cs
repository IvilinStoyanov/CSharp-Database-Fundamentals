﻿namespace PhotoShare.Client.Core.Dtos
{
    public class AlbumRoleDto
    {
        public string Username { get; set; }

        public string AlbumName { get; set; }
    }
}
