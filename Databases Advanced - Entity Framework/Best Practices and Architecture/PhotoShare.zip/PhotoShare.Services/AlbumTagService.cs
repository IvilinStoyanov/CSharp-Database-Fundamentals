﻿namespace PhotoShare.Services
{
    public class AlbumTagService
    {

    }
}
