﻿namespace PhotoShare.Services
{
    public class UserService 
	{
	
    }
}