﻿namespace PhotoShare.Models.Enums
{
    public enum Role
    {
        Owner,
        Viewer
    }
}
